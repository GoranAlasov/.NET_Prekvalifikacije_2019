insert into Sektor values (1, 'Umetnicki sektor', 1);
insert into Sektor values (2, 'Tehnicki sektor', 1);
insert into Sektor values (3, 'Administracija', 1);
insert into Sektor values (4, 'Uprava', 1);
insert into Sektor values (5, 'Nabavka', 1);
commit;