﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zad1
{
    class Program
    {
        static void Main(string[] args)
        {
            string a = "ovo je neki tekst";
            int b = 5;
            bool c = false;

            Console.WriteLine($"Vrednost promenljive a je: {a}.");
            Console.WriteLine($"Vrednost promenljive b je: {b}.");
            Console.WriteLine($"Vrednost promenljive c je: {c}.");
            Console.ReadKey();
        }
    }
}
