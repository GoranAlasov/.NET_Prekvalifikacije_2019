insert into projekat values (10,100, 'Projekat jacanja sistema osiguranja depozita','Evropska banka za obnovu i razvoj');
insert into projekat values (20, 80, 'Mali BIZnis kredit','OB');
insert into projekat values (30, 50, 'Internet bankarstvo','OTI');
insert into projekat values (40, 50, 'Osiguranje','Sintelon');
insert into projekat values (50, 80, 'Gotovinski krediti','KBC');
insert into projekat values (60,100, 'Ziro racuni','Dafiscan');
insert into projekat values (70,100, 'Refinansiranje kredita','DAS');
insert into projekat values (80,100, 'Data Warehouse OB','OTI');
commit;