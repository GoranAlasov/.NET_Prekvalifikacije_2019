﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zad10
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Tommorow we learn C# program flow control.");
            Console.WriteLine("Every command must end with ;");
            Console.ReadLine();
        }
    }
}
