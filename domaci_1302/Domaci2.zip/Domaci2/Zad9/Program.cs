﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zad9
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 10;

            a *= 5;

            Console.WriteLine($"Nova vrednost promenljive a je {a}.");
            Console.ReadKey();
        }
    }
}
