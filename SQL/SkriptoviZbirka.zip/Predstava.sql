insert into Predstava values (10, 'Otelo',  120, 2012);
insert into Predstava values (20, 'Gospodjica', 115, 2013);
insert into Predstava values (30, 'Don Zuan', 125 , 2017);
insert into Predstava values (40, 'Tako je (ako vam se tako cini)', 85 ,2017);
insert into Predstava values (50, 'Zlocin i kazna', 95, 2013);
commit;

